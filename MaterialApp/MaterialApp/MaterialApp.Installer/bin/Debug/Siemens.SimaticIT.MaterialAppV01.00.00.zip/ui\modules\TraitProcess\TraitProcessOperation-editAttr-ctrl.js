﻿(function () {
    'use strict';
    angular.module('Siemens.SimaticIT.MaterialApp.TraitProcess').config(EditScreenStateConfig);

    EditScreenController.$inject = ['Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperation.service', '$state', '$stateParams',
        'common.base', '$filter', '$scope', 'commonService', 'common.services.authentication', 'common.widgets.notificationTile.globalService',
        'common.widgets.busyIndicator.service', '$uibModal', '$rootScope'];
    function EditScreenController(dataService, $state, $stateParams, common, $filter, $scope, commonService, auth, notificationService, busyIndicatorService, $modal, $rootScope) {
        var self = this;
        var sidePanelManager, backendService, propertyGridHandler;

        activate();
        function activate() {
            init();
            registerEvents();

            sidePanelManager.setTitle(commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_1'));
            sidePanelManager.open('e');
        }

        function init() {
            sidePanelManager = common.services.sidePanel.service;
            backendService = common.services.runtime.backendService;

            //Initialize Model Data
            // TODO: Put here the properties of the entity managed by the service
            self.currentItem = angular.copy($stateParams.selectedItem);
            self.validInputs = false;

            self.typeAttr = {
                value: { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_2'), ItemValue: "" },
                options: [
                    { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_2'), ItemValue: "" },
                    { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_3'), ItemValue: "1" },
                    { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_4'), ItemValue: "2" },
                ]
            }

            if (self.currentItem.AttrType == "5") {
                self.typeAttr.value = self.typeAttr.options.find(t => t.ItemName == self.currentItem.AttrValue);
            } else if (self.currentItem.AttrType == "1") {
                self.currentItem.AttrNum = parseFloat(self.currentItem.AttrValue);
            }

            //Expose Model Methods
            self.save = save;
            self.cancel = cancel;

        }

        function registerEvents() {
            $scope.$on('sit-property-grid.validity-changed', onPropertyGridValidityChange);
        }


        //编辑保存
        function save() {
             

            if (self.currentItem.AttrType == "5" && self.typeAttr.value.ItemValue != "") {
                self.currentItem.AttrValue = self.typeAttr.value.ItemName;
            } else if (self.currentItem.AttrType == "1") {
                self.currentItem.AttrValue = self.currentItem.AttrNum + "";
            }

            var postData = {
                KeyValue: self.currentItem.Id,
                Entity: self.currentItem
            };
            busyIndicatorService.show({ message: commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_5') });
            var url = commonService.getMesApiAddress("material") + 'BS_ProcessOfOperations/SaveProcessOfOperationsAttr';

            var req = commonService.callWebApiPost(url, postData).then(onSaveSuccess, onSaveError);
        }

        //取消
        function cancel() {
            //关闭侧边栏
            sidePanelManager.close();
            //返回列表(父页面)
            $state.go('^');
        }

        //保存成功事件
        function onSaveSuccess(data) {

            if (data.data.success) {
                busyIndicatorService.hide();
                //关闭侧边栏
                sidePanelManager.close();
                commonService.showInfo(commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_6'));
                //刷新局部
                $rootScope.$emit('to-parentAttr', 'parent');
                $state.go('^', {}, { reload: false });
            } else {
                busyIndicatorService.hide();
                backendService.genericError(data.data.returnMsg, commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_7'));
            }
        }

        //保存失败事件
        function onSaveError(error) {
            busyIndicatorService.hide();
            backendService.genericError('[' + error.status + '] - ' + error.statusText, commonService.$t('Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_7'));
        }


        function onPropertyGridValidityChange(event, params) {
            self.validInputs = params.validity;
        }
    }

    EditScreenStateConfig.$inject = ['$stateProvider'];
    function EditScreenStateConfig($stateProvider) {
        var screenStateName = 'home.Siemens_SimaticIT_MaterialApp_TraitProcess_TraitProcessOperation';
        var moduleFolder = 'Siemens.SimaticIT.MaterialApp/modules/TraitProcess';

        var state = {
            name: screenStateName + '.editAttr',
            url: '/editAttr/:id',
            views: {
                'property-area-container@': {
                    templateUrl: moduleFolder + '/TraitProcessOperation-editAttr.html',
                    controller: EditScreenController,
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Siemens.SimaticIT.MaterialApp.TraitProcess.TraitProcessOperationeditAttrctrl.Tips_1'
            },
            params: {
                selectedItem: null,
            }
        };
        $stateProvider.state(state);
    }
}());

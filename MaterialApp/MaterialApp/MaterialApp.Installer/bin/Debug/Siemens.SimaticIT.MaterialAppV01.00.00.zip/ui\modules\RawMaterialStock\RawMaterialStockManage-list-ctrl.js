﻿(function () {
    'use strict';
    angular.module('Siemens.SimaticIT.MaterialApp.RawMaterialStock').config(ListScreenRouteConfig);

    ListScreenController.$inject = ['Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManage.service', '$state', '$stateParams',
        '$rootScope', '$scope', 'common.base', 'common.services.logger.service', 'common.widgets.notificationTile.globalService', 'commonService',
        'common.widgets.busyIndicator.service', 'common.services.security.securityService', 'common.services.security.functionRightModel', 'i18nService'];
    function ListScreenController(dataService, $state, $stateParams, $rootScope, $scope, base, loggerService, notificationService,
        commonService, busyIndicatorService, securityService, FunctionRightModel, i18nService) {
        var self = this;
        var logger, rootstate, messageservice, backendService;
        i18nService.setCurrentLang('zh-cn');

        activate();

        // Initialization function
        function activate() {
            logger = loggerService.getModuleLogger('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManage');

            init();
            initGridOptions();

        }

        function init() {
            logger.logDebug('Initializing controller.......');

            rootstate = 'home.Siemens_SimaticIT_MaterialApp_RawMaterialStock_RawMaterialStockManage';
            messageservice = base.widgets.messageOverlay.service;
            backendService = base.services.runtime.backendService;

            //Initialize Model Data
            self.selectedItem = null;
            self.isButtonVisible = false;
            self.searchParams = {};

            //Expose Model Methods
            self.moveButtonHandler = moveButtonHandler;
            self.adjustButtonHandler = adjustButtonHandler;
            self.outWhsButtonHandler = outWhsButtonHandler;
            self.searchButtonHandler = searchButtonHandler;
            self.move2ButtonHandler = move2ButtonHandler; // 调拨
            self.addButtonHandler = addButtonHandler;
            self.TransferButtonHandler = TransferButtonHandler;
            self.backupButtonHandler = backupButtonHandler;
            self.outWhsButtonHandler2 = outWhsButtonHandler2; //出库新
            self.mergeButtonHandler = mergeButtonHandler;//合批
            self.tuikuButtonHandler = tuikuButtonHandler;//退库

            initDictionary();
            self.typeFactoryChange = typeFactoryChange;//工厂change事件
            self.WarehouseChange = WarehouseChange;
            self.selectClick2 = selectClick2;//选择库位

            //按钮权限
            ButtonAuthInitFalse();
            self.RawMaterialStockManageAdd = false;  //新增
            self.RawMaterialStockManageOutWhs = false; //出库
            self.RawMaterialStockManageOutWhs2 = false; //出库-新
            self.RawMaterialStockManageMove = false; //移库
            self.RawMaterialStockManageMove2 = false;  //调拨
            self.RawMaterialStockManageAdjust = false; //库存校准
            self.RawMaterialStockManageBackup = false;//库存备份
            ButtonAuthInit();

        }

        //按钮权限
        function ButtonAuthInitFalse() {
            //1.定义初始按钮
            self.isRawMaterialStockManageAdd = false;
            self.isRawMaterialStockManageOutWhs = false;
            self.isRawMaterialStockManageOutWhs2 = false;
            self.isRawMaterialStockManageMove = false;
            self.isRawMaterialStockManageMove2 = false;
            self.isRawMaterialStockManageAdjust = false;
            self.isRawMaterialStockManageBackup = false;
        }
        //按钮权限
        function ButtonAuthInit() {
            // debugger
            var PageName = "RawMaterialStockManage";
            var jo = {
                PageName: PageName
            };

            var url = commonService.getMesApiAddress() + 'Base/GetButtonAuthList';
            //var url = 'http://localhost:49888/' + 'Base/GetButtonAuthList';
            commonService.callWebApiPost(url, jo).then(function (res) {
                self.funRightListModel = [];

                if ((res) && (res.data.success) && res.data.resultData.length > 0) {
                    //数据
                    for (var i = 0; i < res.data.resultData.length; i++) {
                        self.funRightListModel.push(new FunctionRightModel('business_command', '' + res.data.resultData[i].FullName + '', 'invoke'));
                    }
                    securityService.canPerformOp(self.funRightListModel).then(function (data) {
                        if (data) {
                            if (data.length > 0) {
                                for (var i = 0; i < data.length; i++) {

                                    if (data[i].objectName.split('.')[7] == PageName + "Add") {
                                        self.RawMaterialStockManageAdd = data[i].isAccessible;//新增
                                        self.isRawMaterialStockManageAdd = self.RawMaterialStockManageAdd;
                                    }
                                    else if (data[i].objectName.split('.')[7] == PageName + "OutWhs") {
                                        self.RawMaterialStockManageOutWhs = data[i].isAccessible;//出库
                                        self.isRawMaterialStockManageOutWhs = self.RawMaterialStockManageOutWhs;
                                    }
                                    else if (data[i].objectName.split('.')[7] == PageName + "OutWhs2") {
                                        self.RawMaterialStockManageOutWhs2 = data[i].isAccessible;//出库2
                                        self.isRawMaterialStockManageOutWhs2 = self.RawMaterialStockManageOutWhs2;
                                    }
                                    else if (data[i].objectName.split('.')[7] == PageName + "Move") {
                                        self.RawMaterialStockManageMove = data[i].isAccessible;//移库
                                    }
                                    else if (data[i].objectName.split('.')[7] == PageName + "Move2") {
                                        self.RawMaterialStockManageMove2 = data[i].isAccessible;//调拨
                                    }
                                    else if (data[i].objectName.split('.')[7] == PageName + "Adjust") {
                                        self.RawMaterialStockManageAdjust = data[i].isAccessible;//库存校准
                                    }
                                    else if (data[i].objectName.split('.')[7] == PageName + "Backup") {
                                        self.RawMaterialStockManageBackup = data[i].isAccessible;//库存备份
                                        self.isRawMaterialStockManageBackup = self.RawMaterialStockManageBackup;
                                    }
                                }
                            }
                        }
                    }, function (resError) {
                        backendService.genericError('获取数据出错', resError);
                    });

                } else {
                    backendService.genericError(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_2'), commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_3'));
                }
            }, function (error) {
                backendService.genericError('获取数据出错', commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_4'));
            });
        }

        $rootScope.$on("to-parent", function (event, data) {
            // debugger
            initGridData();
        })

        function initDictionary() {
            //仓库
            self.Warehouse = {
                value: { ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" },
                options: [{ ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" }]
            };
            //库位
            self.Location = {
                value: { ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" },
                options: [{ ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" }]
            };
            //管理方式
            self.ManageMode = {
                value: { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ItemValue: "" },
                options: [{ ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ItemValue: "" },
                { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_6'), ItemValue: "1" },
                { ItemName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_7'), ItemValue: "0" }]
            }

            // let query = {
            //     LevelCode: "Warehouse",
            //     FieldCode: "CKLX",
            //     FieldValue: "1"
            // };
            // commonService.getResourceExtendInfo(query).then(function (res) {
            //     if (res && res.data.success) {
            //         self.Warehouse.options = res.data.resultData;
            //         self.Warehouse.options.splice(0, 0, {
            //             ResourceCode: "",
            //             ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5')
            //         });
            //     }
            // });
            //工厂
            self.typeFactory = {
                value: { ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" },
                options: [{ ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" }]
            };
            commonService.getResourceExtendInfo({ LevelCode: "Factory" }).then(function (res) {
                if (res && res.data.success) {
                    self.typeFactory.options = res.data.resultData;
                    if (res.data.resultData.length > 0) {
                        self.typeFactory.value = res.data.resultData[0];
                    }
                    self.typeFactory.options.splice(0, 0, {
                        ResourceCode: "",
                        ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5')
                    });
                    initGridData();
                }
            });
        }

        function typeFactoryChange(oldItem, newItem) {
            if (newItem.ResourceCode) {
                let query = {
                    factoryCode: newItem.ResourceCode
                };
                commonService.getWarehouseByFactory(query).then(function (res) {
                    if (res && res.data.success) {
                        self.Warehouse.options = res.data.resultData;
                        self.Warehouse.options.splice(0, 0, {
                            ResourceCode: "",
                            ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5')
                        });
                    }
                });
            } else {
                self.Warehouse = {
                    value: { ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" },
                    options: [{ ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5'), ResourceCode: "" }]
                };
            }
        }
        //仓库改变事件
        function WarehouseChange(oldItem, newItem) {
            commonService.getResourceListByParentResource({ ParentResource: newItem.ResourceCode }).then(function (res) {
                if (res && res.data.success) {
                    self.Location.options = res.data.resultData;
                    self.Location.options.splice(0, 0, {
                        ResourceCode: "",
                        ResourceName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_5')
                    });
                }
            });
        }


        function selectClick2() {
            if (!self.Warehouse.value.ResourceCode) {
                backendService.genericError(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_8'), commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_9'));
                return;
            }
            var modalInstance = commonService.openModel({
                templateUrl: 'CCS.CommonApp/modules/CommonUI/SelectMaterialModal.html',
                controller: 'CCS.CommonApp.CommonUI.SelectMaterialModal',
                controllerAs: 'vm',
                size: 'lg',
                resolve: {
                    data: function () {
                        return {
                            url: commonService.getMesApiAddress("factory") + 'level/GetListByParentResource',
                            queryParmeters: {
                                Name: "",
                                ParentResource: self.Warehouse.value.ResourceCode
                            },
                            multiple: false,
                            isFilter: "0",
                            method: "Post",
                            sidx: "ResourceCode",
                            sord: "asc",
                            columnDefs: [
                                {
                                    name: 'rowNum', displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_10'), minWidth: 80, width: 90, enableSorting: false, cellTemplate:
                                        '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row) + 1}}</div>'
                                },
                                {
                                    field: 'ResourceCode',
                                    displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_11'),
                                    width: 200
                                },
                                {
                                    field: 'ResourceName',
                                    displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_12'),
                                    width: 350
                                }
                            ],
                        };
                    }
                }
            });
            modalInstance.result.then(function (data) {
                if ((!data || data.length <= 0)) {
                    showWarning(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_13'));
                } else {
                    self.searchParams.LocationCode = data[0].ResourceCode;
                    self.searchParams.LocationName = data[0].ResourceName;
                }
            });
        }

        //初始化grid选项
        function initGridOptions() {
            self.gridOptions = {
                fastWatch: true,
                rowHeight: 35,
                minimumColumnSize: 100,
                enableMultiSelection: false,
                enableFiltering: false,
                //基础属性
                enableSorting: true,//是否支持排序(列)
                useExternalSorting: false,//是否支持自定义的排序规则
                enableGridMenu: false,//是否显示表格 菜单
                showGridFooter: false,//时候显示表格的footer
                enableHorizontalScrollbar: 1,//表格的水平滚动条
                enableVerticalScrollbar: 1,//表格的垂直滚动条 (两个都是 1-显示,0-不显示)
                selectionRowHeaderWidth: 30,
                enableCellEditOnFocus: false,//default为false,true的时候单击即可打开编辑(cellEdit为true的时候,需要引入'ui.grid.cellNav')
                //分页属性
                enablePagination: true, //是否分页,default为true
                enablePaginationControls: true, //使用默认的底部分页
                paginationPageSizes: [20, 30, 50, 70, 90, 100], //每页显示个数选项
                paginationPageSize: 20, //每页显示个数
                paginationCurrentPage: 1, //当前的页码  
                totalItems: 0, // 总数量
                useExternalPagination: true,//是否使用分页按钮
                //选中
                rowTemplate: " <div ng-dblclick =\"grid.appScope.onDblClick(row)\" ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\" class=\"ui-grid-cell\" ng-class=\"{ 'ui-grid-row-header-cell': col.isRowHeader }\" ui-grid-cell></div>",//双击行事件
                enableFooterTotalSelected: true, // 是否显示选中的总数,default为true,如果显示,showGridFooter 必须为true
                enableFullRowSelection: false, //是否点击行任意位置后选中,default为false,当为true时,checkbox可以显示但是不可选中
                enableRowHeaderSelection: true, //是否显示选中checkbox框 ,default为true
                enableRowSelection: false, // 行选择是否可用,default为true;
                enableSelectAll: false, // 选择所有checkbox是否可用，default为true; 
                enableSelectionBatchEvent: true, //default为true
                modifierKeysToMultiSelect: false,//default为false,为true时只能按ctrl或shift键进行多选,这个时候multiSelect必须为true;
                multiSelect: true,// 是否可以选择多个,默认为true;
                noUnselect: false,//default为false,选中后是否可以取消选中
                appScopeProvider: self,
                columnDefs: [
                    {
                        name: 'rowNum', displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_10'), width: 80, enableSorting: false, cellTemplate:
                            '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row) + 1}}</div>'
                    },
                    {
                        field: 'FactoryName',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_14'),
                        width: 110
                    },
                    {
                        field: 'WhsName',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_15'),
                        width: 200
                    },
                    {
                        field: 'LocationName',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_11'),
                        width: 200
                    },
                    {
                        field: 'ManageMode',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_16'),
                        width: 120
                    },
                    {
                        field: 'MaterialCode',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_17'),
                        width: 150
                    },
                    {
                        field: 'MaterialName',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_18'),
                        width: 200
                    },
                    {
                        field: 'Spec',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_19'),
                        width: 120
                    },
                    {
                        field: 'SmallClassName',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_20'),
                        width: 120
                    },
                    {
                        field: 'SupplierName',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_21'),
                        width: 150
                    },
                    {
                        field: 'BatchNo',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_22'),
                        width: 150
                    },
                    {
                        field: 'Unit',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_23'),
                        width: 80
                    },
                    {
                        field: 'Qty',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_24'),
                        width: 110
                    },
                    {
                        field: 'Remark',
                        displayName: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_25'),
                        width: 200
                    }
                ],
                //---------------api---------------------
                onRegisterApi: function (gridApi) {
                    $scope.gridApi = gridApi;
                    //分页按钮事件
                    gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        //调用查询方法
                        initGridData();



                    });
                    //行选中事件
                    $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row, event) {
                        if (row) {
                            if (row.isSelected) {
                                self.selectedItem = row.entity;
                                self.isButtonVisible = true;

                                //按钮权限
                                // self.isRawMaterialStockManageOutWhs = self.RawMaterialStockManageOutWhs;
                                self.isRawMaterialStockManageMove = self.RawMaterialStockManageMove;
                                self.isRawMaterialStockManageMove2 = self.RawMaterialStockManageMove2;
                                self.isRawMaterialStockManageAdjust = self.RawMaterialStockManageAdjust;

                            } else {
                                self.selectedItem = null;
                                self.isButtonVisible = false;
                                //按钮权限
                                ButtonAuthInitFalse();
                                self.isRawMaterialStockManageAdd = self.RawMaterialStockManageAdd;
                                self.isRawMaterialStockManageOutWhs = self.RawMaterialStockManageOutWhs;
                                self.isRawMaterialStockManageOutWhs2 = self.RawMaterialStockManageOutWhs2;
                                self.isRawMaterialStockManageBackup = self.RawMaterialStockManageBackup;
                            }
                        }
                    });
                },
                data: []
            }
        }

        //查询方法,数据绑定
        function initGridData() {
            self.selectedItem = null;
            self.isButtonVisible = false;
            //按钮权限
            ButtonAuthInitFalse();
            self.isRawMaterialStockManageAdd = self.RawMaterialStockManageAdd;
            self.isRawMaterialStockManageOutWhs = self.RawMaterialStockManageOutWhs;
            self.isRawMaterialStockManageOutWhs2 = self.RawMaterialStockManageOutWhs2;
            self.isRawMaterialStockManageBackup = self.RawMaterialStockManageBackup;

            if (!self.typeFactory.value.ResourceCode) {
                commonService.showWarning(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_26'))
                return;
            }

            let Pagination = {
                rows: self.gridOptions.paginationPageSize,
                page: self.gridOptions.paginationCurrentPage,
                sidx: 'WhsCode,LocationCode,MaterialCode',//仓库编码、物料编码
                sord: 'asc'
            };
            if (self.searchParams.LocationName == "" || self.searchParams.LocationName == null) {
                self.searchParams.LocationCode = "";
            }
            self.searchParams.FactoryCode = self.typeFactory.value.ResourceCode;
            self.searchParams.WhsCode = self.Warehouse.value.ResourceCode;
            // self.searchParams.LocationCode = self.Location.value.ResourceCode;
            self.searchParams.ManageMode = self.ManageMode.value.ItemValue;
            let queryParmeters = {
                pagination: Pagination,
                queryJson: self.searchParams
            };
            var url = commonService.getMesApiAddress("material") + 'MM_RawMaterialStock/MM_RawMaterialStockPageDataTableList';
            commonService.callWebApiPost(url, queryParmeters).then(function (res) {
                if ((res) && (res.data.success)) {
                    //总条数
                    self.gridOptions.totalItems = res.data.resultData.records;
                    //数据
                    self.gridOptions.data = res.data.resultData.rows;
                } else {
                    self.gridOptions.data = [];
                }
            }, function (error) {
                backendService.genericError('获取数据出错', commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_1'));
            });
        }

        //查询
        function searchButtonHandler() {
            initGridData();
        }

        //跨工厂调拨
        function TransferButtonHandler() {
            var data = $scope.gridApi.selection.getSelectedRows();
            var WhsName = data[0].WhsName;
            var IsWhsName = 0;
            //判断选择的物料是不是同一个仓库
            data.forEach((item, index, arr) => {
                if (item.WhsName != WhsName) {
                    IsWhsName = IsWhsName + 1;
                }
            });
            if (IsWhsName > 0) {
                commonService.showWarning(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_27'))
                return;
            }
            $state.go(rootstate + '.Transfer', { selectedItem: data });
        }
        //新增
        function addButtonHandler(clickedCommand) {
            $state.go(rootstate + '.addDetail');
        }

        //移库
        // function moveButtonHandler(clickedCommand) {
        //     $state.go(rootstate + '.edit', { id: self.selectedItem.Id, selectedItem: self.selectedItem });
        // }
        function moveButtonHandler(clickedCommand) {
            $state.go(rootstate + '.Newedit');
        }
        //function move2ButtonHandler(clickedCommand) {
        //    $state.go(rootstate + '.add', { id: self.selectedItem.Id, selectedItem: self.selectedItem });
        //}
        // 调拨
        function move2ButtonHandler(clickedCommand) {
            $state.go(rootstate + '.Newadd');
        }
        //库存校准
        function adjustButtonHandler(clickedCommand) {
            // TODO: Put here the properties of the entity managed by the service
            $state.go(rootstate + '.adjust', { id: self.selectedItem.Id, selectedItem: self.selectedItem });
        }
        //出库
        function outWhsButtonHandler(clickedCommand) {
            // TODO: Put here the properties of the entity managed by the service
            $state.go(rootstate + '.out');
        }
        //出库 -新
        function outWhsButtonHandler2(clickedCommand) {
            // TODO: Put here the properties of the entity managed by the service
            $state.go(rootstate + '.out2');
        }

        //合批
        function mergeButtonHandler(clickedCommand) {
            //同一仓库、、物料、供应商 可以合批

            let selRows = $scope.gridApi.selection.getSelectedRows();
            if (selRows.length <= 1) {
                //请选择要合批的数据
                commonService.showWarning(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_32'));
                return;
            }

            //2025-03-06 去掉供应商
            // 根据仓库、、物料进行去重
            const uniqueArr = Array.from(new Set(selRows.map((item) => JSON.stringify([item.WhsCode, item.MaterialCode]))));
            console.log(uniqueArr); // ["[1,"Alice"]", "[2,"Bob"]", "[3,"Charlie"]"]

            // 还原成对象格式
            const result = uniqueArr.map((str) => JSON.parse(str)).map(([WhsCode, MaterialCode]) => ({ WhsCode, MaterialCode }));
            console.log(result); // [{ id: 1, name: "Alice" },{ id: 2, name: "Bob" },{ id: 3, name: "Charlie" }]
            if (result.length > 1) {
                //同一仓库、、物料才可以合批
                commonService.showWarning(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_33'));
                return;
            }
            //不同批次才可以合批
            const arrBatchNo = [...new Set(selRows.map(item => { return item.BatchNo; }))];
            if (arrBatchNo.length < selRows.length) {
                //相同的批次不可以合批
                commonServicem.showWarning(commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_34'));
                return;
            }

            $state.go(rootstate + '.merge', { selectedItem: selRows });
        }

        //退库
        function tuikuButtonHandler(clickedCommand) {
            $state.go(rootstate + '.tuiku');
        }

        //库存备份
        function backupButtonHandler() {
            var title = commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_28');
            var text = commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_29');
            backendService.confirm(text, function () {
                var url = commonService.getMesApiAddress("material") + 'MM_RawMaterialStock/StockBackup';
                busyIndicatorService.show({ message: commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_30') });
                commonService.callWebApiPost(url, null).then(function (res) {
                    busyIndicatorService.hide();
                    if ((res) && (res.data.success)) {
                        var resultData = res.data.resultData;
                        //成功
                        commonService.showInfo(res.data.returnMsg);
                    } else {
                        //失败
                        commonService.showWarning(res.data.returnMsg);
                    }
                }, function (error) {
                    backendService.genericError('[' + error.status + '] - ' + error.statusText + '-' + error.data.returnMsg, commonService.$t('Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_1'));
                });
            }, title);
        }

        function onGridItemSelectionChanged(items, item) {
            if (item && item.selected == true) {
                self.selectedItem = item;
                setButtonsVisibility(true);
            } else {
                self.selectedItem = null;
                setButtonsVisibility(false);
            }
        }

        // Internal function to make item-specific buttons visible
        function setButtonsVisibility(visible) {
            self.isButtonVisible = visible;
        }
    }

    ListScreenRouteConfig.$inject = ['$stateProvider'];
    function ListScreenRouteConfig($stateProvider) {
        var moduleStateName = 'home.Siemens_SimaticIT_MaterialApp_RawMaterialStock';
        var moduleStateUrl = 'Siemens.SimaticIT_MaterialApp_RawMaterialStock';
        var moduleFolder = 'Siemens.SimaticIT.MaterialApp/modules/RawMaterialStock';

        var state = {
            name: moduleStateName + '_RawMaterialStockManage',
            url: '/' + moduleStateUrl + '_RawMaterialStockManage',
            views: {
                'Canvas@': {
                    templateUrl: moduleFolder + '/RawMaterialStockManage-list.html',
                    controller: ListScreenController,
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Siemens.SimaticIT.MaterialApp.RawMaterialStock.RawMaterialStockManagelistctrl.Tips_31'
            }
        };
        $stateProvider.state(state);
    }
}());
